.onLoad <- function(libname, pkgname) {
  #library(knitr)
  knitr::opts_chunk$set(tidy = 'styler',comment='',highlight=TRUE, copy=TRUE)

  `%n%` <- knitr:::`%n%`

  knitr::knit_hooks$set(source = function(x, options) {
    copy <- options$copy %n% FALSE
    xx <- x

    x <- knitr:::one_string(x)
    #x = paste0("```r\n",x,"\n```")
    id <- options$label %n% "null"
    if(copy){
      #x <- knitr:::hilight_source(x = x, format = "html", options = options)

      x <- glue::glue('<button type="button" id="copy-button" data-clipboard-target="#{id}" class="copy-button btn btn-primary">Copy code</button><pre class="r" id="{id}"><code>{x}</code></pre>')}
    x
  })


knitr::knit_engines$set(hint = function(options)
  {
    iscode = options$type %n% "details"
    if (isFALSE(options$echo))
      return()
    code = knitr:::one_string(options$code)
    if(iscode == "code"){
      code = paste0("```r",code,"```")
    }
    to = knitr:::pandoc_to()
    is_pandoc = !is.null(to)
    if (!is_pandoc) {
      to = out_format()
      if (!(to %in% c("latex", "html", "markdown")))
        to = NULL
    }
    if (is.null(to))
      return(code)
    if (to == "beamer")
      to = "latex"
    if (is_html_output(to))
      to = "html"
    type = "details"#options$type
    if (is.null(type))
      return(code)
    if (is_pandoc)
      code = knitr:::pandoc_fragment(code, if (to == "html")
        "html4"
        else to)
    l1 = options$latex.options
    if (is.null(l1))
      l1 = ""
    h2 = options$html.tag %n% "details"
    h3 = options$html.before %n% ""
    h4 = options$html.after %n% ""
    if (to %in% names(type))
      type = type[to]
    if (to == "html")
      if (h2 %in% c("div", "p", "blockquote")) {
        code = paste0("\n", code, "\n")
      }
    else {
      code = gsub("<p>", "<span class=\"hintBody\" style=\"display: block;\">",
                  code)
      code = gsub("</p>", "</span>", code)
    }
    switch(to, latex = sprintf("\\begin{%s}%s\n%s\n\\end{%s}",
                               type, l1, code, type), html = sprintf("%s<%s class=\"%s\"><summary class=\"hintHead\">Get a hint</summary>%s</%s>%s",
                                                                     h3, h2, type, code, h2, h4), code)
  })


  knitr::knit_hooks$set(solution = function(before, options, envir) {
    if (before) {
      "<details><summary>Solution</summary><p class=\"output-text\"><code>R</code> Input</p>"
    } else {
      "</details>"
    }
  })

  knitr::knit_hooks$set(sourcse = function(x, options) {
    copy <- options$copy %n% FALSE
    xx <- x

    x <- knitr:::one_string(x)
    #x <- knitr:::pandoc_fragment(text = x, to = "html4")

    id <- options$label %n% "null"
    if(copy){

      x <- glue::glue('<button type="button" id="copy-button" data-clipboard-target="#{id}" class="copy-button btn btn-primary">Copy code</button><pre id="{id}"><code class="R">{x}</code></pre>')}
    x
  })


}
