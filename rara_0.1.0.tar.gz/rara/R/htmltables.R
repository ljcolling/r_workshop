html_table <- function(x, dom = 'tpr'){
  width = dim(x)[2]-1
  DT::datatable(x,rownames = FALSE,style = "default",  extensions = c('FixedColumns'),
                options = list(dom = dom, scrollX = TRUE, fixedColumns = TRUE,
                               columnDefs = list(list(className = 'dt-center', targets = 0:width))))

}

html_table_part <- purrr::partial(DT::datatable,
                                  rownames = FALSE,style = "default",  extensions = c('FixedColumns'),
                                  options = list(dom = 'tpr', scrollX = TRUE, fixedColumns = TRUE,
                                                 columnDefs = list(list(className = 'dt-center', targets = 0:x))))
